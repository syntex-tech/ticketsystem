<?PHP header('Access-Control-Allow-Origin: *');?>
<?PHP header('Location: /pages/login/login.html');?>