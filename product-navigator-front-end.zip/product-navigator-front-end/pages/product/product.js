document.addEventListener("DOMContentLoaded", () => {
    const vars = getVariables();
    setScreen(vars);

    document.querySelector(".addProduct").addEventListener("submit", e => {
        e.preventDefault();

        const productData = {
            marketID: vars['marketID'],
            name: document.getElementById("addName").value,
            price: document.getElementById("addPrice").value,
            kcal: document.getElementById("addKcal").value,
            fat: document.getElementById("addFat").value,
            carbohydrate: document.getElementById("addCarbohydrate").value,
            protein: document.getElementById("addProtein").value,
            salt: document.getElementById("addSalt").value,
            location: document.getElementById("addLocation").value,
            stock: document.getElementById("addStock").value
        }

        fetch("https://product-navigator-back-end.herokuapp.com/api/products/addProduct", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(productData),
        })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            if (data.message == "Product added") {
                window.close();
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    });

    document.querySelector("#updateButton").addEventListener("click", e => {
        e.preventDefault();

        const productData = {
            marketID: vars['marketID'],
            name: document.getElementById("updateName").value,
            price: document.getElementById("updatePrice").value,
            kcal: document.getElementById("updateKcal").value,
            fat: document.getElementById("updateFat").value,
            carbohydrate: document.getElementById("updateCarbohydrate").value,
            protein: document.getElementById("updateProtein").value,
            salt: document.getElementById("updateSalt").value,
            location: document.getElementById("updateLocation").value,
            stock: document.getElementById("updateStock").value
        }

        fetch("https://product-navigator-back-end.herokuapp.com/api/products/updateProduct", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(productData),
        })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            if (data.message == "Product updated") {
                window.close();
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    });

    document.querySelector("#deleteButton").addEventListener("click", e => {
        e.preventDefault();

        const productData = {
            marketID: vars['marketID'],
            name: document.getElementById("updateName").value,
            price: document.getElementById("updatePrice").value,
            kcal: document.getElementById("updateKcal").value,
            fat: document.getElementById("updateFat").value,
            carbohydrate: document.getElementById("updateCarbohydrate").value,
            protein: document.getElementById("updateProtein").value,
            salt: document.getElementById("updateSalt").value,
            location: document.getElementById("updateLocation").value,
            stock: document.getElementById("updateStock").value
        }

        fetch("https://product-navigator-back-end.herokuapp.com/api/products/deleteProduct", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(productData),
        })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            if (data.message == "Product deleted") {
                window.close();
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    });
});

function getVariables() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        value = value.replace(/%20/g, " ");
        value = value.replace(/%C3%A4/g, "ä");
        value = value.replace(/%C3%BC/g, "ü");
        value = value.replace(/%C3%B6/g, "ö");
        value = value.replace(/%C3%9F/g, "ß");
        value = value.replace(/%C3%84/g, "Ä");
        value = value.replace(/%C3%96/g, "Ö");
        value = value.replace(/%C3%9C/g, "Ü");
        vars[key] = value;
    });
    return vars;
}

function setScreen(vars) {
    const addProduct = document.querySelector(".addProduct");
    const updateProduct = document.querySelector(".updateProduct");

    if (vars['type'] == 'addProduct') {
        addProduct.classList.remove("section--hidden");
        updateProduct.classList.remove("section--hidden");

        updateProduct.classList.add("section--hidden");
    }
    else if (vars['type'] == 'updateProduct') {
        addProduct.classList.remove("section--hidden");
        updateProduct.classList.remove("section--hidden");

        addProduct.classList.add("section--hidden");

        document.getElementById("updateName").value = vars['name'];
        document.getElementById("updatePrice").value = vars['price'];
        document.getElementById("updateKcal").value = vars['kcal'];
        document.getElementById("updateFat").value = vars['fat'];
        document.getElementById("updateCarbohydrate").value = vars['carbohydrate'];
        document.getElementById("updateProtein").value = vars['protein'];
        document.getElementById("updateSalt").value = vars['salt'];
        document.getElementById("updateLocation").value = vars['location'];
        document.getElementById("updateStock").value = vars['stock'];
    }
}