let products = [];

document.addEventListener("DOMContentLoaded", () => {
    const userProfile = document.querySelector("#user");
    const main = document.querySelector("#main");

    const userProfile_personal = document.querySelector(".personal");
    const userProfile_location = document.querySelector(".location");
    const userProfile_settings = document.querySelector(".settings");
    const userProfile_transfers = document.querySelector(".transfers");
    const userProfile_bookmarks = document.querySelector(".bookmarks");

    searchProducts();

    document.querySelector("#icon").addEventListener("click", () => {
        userProfile.classList.remove("section--hidden");
        main.classList.remove("section--hidden");
        userProfile.classList.add("section--hidden");
    });

    document.querySelector("#profile").addEventListener("click", () => {
        userProfile.classList.remove("section--hidden");
        main.classList.remove("section--hidden");
        main.classList.add("section--hidden");
        personal();
        setUserData();
    });

    document.querySelector("#personal").addEventListener("click", () => {
        personal();
    });

    document.querySelector("#location").addEventListener("click", () => {
        userProfile_personal.classList.remove("section--hidden");
        userProfile_location.classList.remove("section--hidden");
        userProfile_settings.classList.remove("section--hidden");
        userProfile_transfers.classList.remove("section--hidden");
        userProfile_bookmarks.classList.remove("section--hidden");

        userProfile_personal.classList.add("section--hidden");
        userProfile_settings.classList.add("section--hidden");
        userProfile_transfers.classList.add("section--hidden");
        userProfile_bookmarks.classList.add("section--hidden");

        document.getElementById("personal").classList.remove("section--selected");
        document.getElementById("location").classList.remove("section--selected");
        document.getElementById("settings").classList.remove("section--selected");
        document.getElementById("transfers").classList.remove("section--selected");
        document.getElementById("bookmarks").classList.remove("section--selected");

        document.getElementById("location").classList.add("section--selected");

        // Diese Funktion ist leider fehlerhaft, da die Google API Geld für die Nutzung verlangt, anders wäre dies nutzbar
        var geocoder = new google.maps.Geocoder();
        var address = document.getElementById("city").value + " " + document.getElementById("street").value;

        geocoder.geocode({
            'address': address,
        }, function(results, status) {
            if (status == google.maps.GeocoderStatus.OK) {
                var latitude = results[0].geometry.location.lat();
                var longitude = results[0].geometry.location.lng();
                initMap(latitude, longitude);
            } 
        }); 
    });

    document.querySelector("#settings").addEventListener("click", () => {
        userProfile_personal.classList.remove("section--hidden");
        userProfile_location.classList.remove("section--hidden");
        userProfile_settings.classList.remove("section--hidden");
        userProfile_transfers.classList.remove("section--hidden");
        userProfile_bookmarks.classList.remove("section--hidden");

        userProfile_personal.classList.add("section--hidden");
        userProfile_location.classList.add("section--hidden");
        userProfile_transfers.classList.add("section--hidden");
        userProfile_bookmarks.classList.add("section--hidden");

        document.getElementById("personal").classList.remove("section--selected");
        document.getElementById("location").classList.remove("section--selected");
        document.getElementById("settings").classList.remove("section--selected");
        document.getElementById("transfers").classList.remove("section--selected");
        document.getElementById("bookmarks").classList.remove("section--selected");

        document.getElementById("settings").classList.add("section--selected");
    });

    document.querySelector("#transfers").addEventListener("click", () => {
        userProfile_personal.classList.remove("section--hidden");
        userProfile_location.classList.remove("section--hidden");
        userProfile_settings.classList.remove("section--hidden");
        userProfile_transfers.classList.remove("section--hidden");
        userProfile_bookmarks.classList.remove("section--hidden");

        userProfile_personal.classList.add("section--hidden");
        userProfile_location.classList.add("section--hidden");
        userProfile_settings.classList.add("section--hidden");
        userProfile_bookmarks.classList.add("section--hidden");

        document.getElementById("personal").classList.remove("section--selected");
        document.getElementById("location").classList.remove("section--selected");
        document.getElementById("settings").classList.remove("section--selected");
        document.getElementById("transfers").classList.remove("section--selected");
        document.getElementById("bookmarks").classList.remove("section--selected");

        document.getElementById("transfers").classList.add("section--selected");
    });

    document.querySelector("#bookmarks").addEventListener("click", () => {
        userProfile_personal.classList.remove("section--hidden");
        userProfile_location.classList.remove("section--hidden");
        userProfile_settings.classList.remove("section--hidden");
        userProfile_transfers.classList.remove("section--hidden");
        userProfile_bookmarks.classList.remove("section--hidden");

        userProfile_personal.classList.add("section--hidden");
        userProfile_location.classList.add("section--hidden");
        userProfile_settings.classList.add("section--hidden");
        userProfile_transfers.classList.add("section--hidden");

        document.getElementById("personal").classList.remove("section--selected");
        document.getElementById("location").classList.remove("section--selected");
        document.getElementById("settings").classList.remove("section--selected");
        document.getElementById("transfers").classList.remove("section--selected");
        document.getElementById("bookmarks").classList.remove("section--selected");

        document.getElementById("bookmarks").classList.add("section--selected");
    });

    document.querySelector(".searchText").addEventListener("keyup", () => {
        searchProducts();
    });

    document.querySelector("#addProduct").addEventListener("click", () => {
        const marketID = document.getElementById("marketID").textContent;
        popUpWindow('/pages/product/product.html?type=addProduct&marketID=' + marketID,'Add Product','700','600');
    });

    userProfile_personal.addEventListener("submit", e => {
        e.preventDefault();

        let username = document.getElementById('username').value;
        let email = document.getElementById('email').value;
        let password = document.getElementById('password').value;
        let birthday = document.getElementById('birthday').value;

        const personalUpdate = {
            name: username,
            email: email,
            password: password,
            birthday: birthday
        };

        fetch("https://product-navigator-back-end.herokuapp.com/api/user/update", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(personalUpdate),
        })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            if (data.result == "true") {
                setFormMessage(userProfile_personal, "success", "User Information updated");
                window.location = "../home/home.html?name="+data.name+"&birthday="+data.birthday+"&email="+data.email+"&password="+data.password+"&city="+data.city+"&street="+data.street;
            } else {
                setFormMessage(userProfile_personal, "error", "Error");
            }
        })
        .catch(function (error) {
            console.log(error);
        });
    });

    userProfile_location.addEventListener("submit", e => {
        e.preventDefault();

        let username = document.getElementById('username').value;
        let email = document.getElementById('email').value;
        let password = document.getElementById('password').value;
        let street = document.getElementById('street').value;
        let city = document.getElementById('city').value;

        const locationUpdate = {
            name: username,
            email: email,
            password: password,
            street: street,
            city: city
        };

        fetch("https://product-navigator-back-end.herokuapp.com/api/user/update", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(locationUpdate),
            })
            .then((response) => {
                return response.json();
            })
            .then(function (data) {
                if (data.result == "true") {
                    setFormMessage(userProfile_personal, "success", "Location Information updated");
                    window.location = "../home/home.html?name="+data.name+"&birthday="+data.birthday+"&email="+data.email+"&password="+data.password+"&city="+data.city+"&street="+data.street;
                } else {
                    setFormMessage(userProfile_personal, "error", "Error");
                }
            })
            .catch((error) => {
                console.log(error);
            });
    });
});

function personal() {
    const userProfile_personal = document.querySelector(".personal");
    const userProfile_location = document.querySelector(".location");
    const userProfile_settings = document.querySelector(".settings");
    const userProfile_transfers = document.querySelector(".transfers");
    const userProfile_bookmarks = document.querySelector(".bookmarks");

    userProfile_personal.classList.remove("section--hidden");
    userProfile_location.classList.remove("section--hidden");
    userProfile_settings.classList.remove("section--hidden");
    userProfile_transfers.classList.remove("section--hidden");
    userProfile_bookmarks.classList.remove("section--hidden");

    userProfile_location.classList.add("section--hidden");
    userProfile_settings.classList.add("section--hidden");
    userProfile_transfers.classList.add("section--hidden");
    userProfile_bookmarks.classList.add("section--hidden");

    document.getElementById("personal").classList.remove("section--selected");
    document.getElementById("location").classList.remove("section--selected");
    document.getElementById("settings").classList.remove("section--selected");
    document.getElementById("transfers").classList.remove("section--selected");
    document.getElementById("bookmarks").classList.remove("section--selected");

    document.getElementById("personal").classList.add("section--selected");
}

function initMap(lat, lng) {
    const pos = {lat, lng};
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 12,
        center: pos,
    });
    const marker = new google.maps.Marker({
        position: pos,
        map: map,
    });
}

function setFormMessage(formElement, type, message) {
    const messageElement = formElement.querySelector(".form__message");

    messageElement.textContent = message;
    messageElement.classList.remove("form__message--success", "form__message--error");
    messageElement.classList.add(`form__message--${type}`);
}

function removeFormMessage(formElement) {
    const messageElement = formElement.querySelector(".form__message");

    messageElement.textContent = "";
    messageElement.classList.remove("form__message--success", "form__message--error");
}

function setUserData() {
    var vars = {};
    var parts = window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) {
        value = value.replace(/%20/g, " ");
        value = value.replace(/%C3%A4/g, "ä");
        value = value.replace(/%C3%BC/g, "ü");
        value = value.replace(/%C3%B6/g, "ö");
        value = value.replace(/%C3%9F/g, "ß");
        value = value.replace(/%C3%84/g, "Ä");
        value = value.replace(/%C3%96/g, "Ö");
        value = value.replace(/%C3%9C/g, "Ü");
        vars[key] = value;
    });

    try {
        document.getElementById('username').value = vars['name'];
        document.getElementById('birthday').value = vars['birthday'];
        document.getElementById('email').value = vars['email'];
        document.getElementById('password').value = vars['password'];
        document.getElementById('city').value = vars['city'];
        document.getElementById('street').value = vars['street'];
    }
    catch(err) {
        console.log(err);
    }
}

function startPopUp(id) {
    const marketID = document.getElementById("marketID").textContent;

    let name = document.getElementById(`p${id}name`).textContent;
    let price = "";
    let kcal = "";
    let fat = "";
    let carbohydrate = "";
    let protein = "";
    let salt = "";
    let location = "";
    let stock = "";

    for (let i = 0; i < products.length; i++) {
        if (name == products[i].name) {
            price = products[i].price;
            kcal = products[i].kcal;
            fat = products[i].fat;
            carbohydrate = products[i].carbohydrate;
            protein = products[i].protein;
            salt = products[i].salt;
            location = products[i].location;
            stock = products[i].stock;
        }
    }

    popUpWindow('/pages/product/product.html?type=updateProduct&marketID='+marketID+"&name="+name+"&price="+price+"&kcal="+kcal+"&fat="+fat+"&carbohydrate="+carbohydrate+"&protein="+protein+"&salt="+salt+"&location="+location+"&stock="+stock,'Update Product','700','600');
}

function popUpWindow(URL, windowName, windowWidth, windowHeight) {
    var centerLeft = (screen.width/2)-(windowWidth/2);
    var centerTop = (screen.height/2)-(windowHeight/2);
    var windowFeatures = 'toolbar=no, location=no, directories=no, status=no, menubar=no, titlebar=no, scrollbars=no, resizable=no, ';
    var popUp = window.open(URL, 'null', windowName, windowFeatures +' width='+ windowWidth +', height='+ windowHeight +', top='+ centerTop +', left='+ centerLeft);
    popUp.onbeforeunload = function() {
        document.querySelector(".searchText").value = "";
        searchProducts();
    }
}

function setProductData(product) {
    document.getElementById("p1name").textContent = "";
    document.getElementById("p2name").textContent = "";
    document.getElementById("p3name").textContent = "";
    document.getElementById("p4name").textContent = "";
    document.getElementById("p5name").textContent = "";
    document.getElementById("p6name").textContent = "";
    document.getElementById("p7name").textContent = "";
    document.getElementById("p8name").textContent = "";
    document.getElementById("p9name").textContent = "";
    document.getElementById("p10name").textContent = "";
    document.getElementById("p11name").textContent = "";
    document.getElementById("p12name").textContent = "";
    document.getElementById("p13name").textContent = "";
    document.getElementById("p14name").textContent = "";
    document.getElementById("p15name").textContent = "";
    document.getElementById("p16name").textContent = "";
    document.getElementById("p17name").textContent = "";
    document.getElementById("p18name").textContent = "";
    document.getElementById("p19name").textContent = "";
    document.getElementById("p20name").textContent = "";

    for (let i = 0; i < product.length; i++) {
        document.getElementById(`p${i+1}name`).textContent = product[i].name;
    }
}

function setMarket(id) {
    document.getElementById("market--title").textContent = document.getElementById(`market${id}--title`).textContent;
    document.getElementById("market--street").innerHTML = document.getElementById(`market${id}--street`).innerHTML;
    document.getElementById("market--city").innerHTML = document.getElementById(`market${id}--city`).innerHTML;

    document.getElementById("marketID").textContent = id;

    document.getElementById("p1name").textContent = "";
    document.getElementById("p2name").textContent = "";
    document.getElementById("p3name").textContent = "";
    document.getElementById("p4name").textContent = "";
    document.getElementById("p5name").textContent = "";
    document.getElementById("p6name").textContent = "";
    document.getElementById("p7name").textContent = "";
    document.getElementById("p8name").textContent = "";
    document.getElementById("p9name").textContent = "";
    document.getElementById("p10name").textContent = "";
    document.getElementById("p11name").textContent = "";
    document.getElementById("p12name").textContent = "";
    document.getElementById("p13name").textContent = "";
    document.getElementById("p14name").textContent = "";
    document.getElementById("p15name").textContent = "";
    document.getElementById("p16name").textContent = "";
    document.getElementById("p17name").textContent = "";
    document.getElementById("p18name").textContent = "";
    document.getElementById("p19name").textContent = "";
    document.getElementById("p20name").textContent = "";

    document.querySelector(".searchText").value = "";

    searchProducts();
}

function searchProducts() {
    const string = {
        name: document.querySelector(".searchText").value,
        marketID: document.getElementById("marketID").textContent
    }

    fetch("https://product-navigator-back-end.herokuapp.com/api/products/searchProduct", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(string)
    })
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        setProductData(data);
        products = data;
    })
    .catch(function (error) {
        console.log(error);
    });
}